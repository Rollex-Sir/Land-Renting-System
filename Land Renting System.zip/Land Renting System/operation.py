import read
import write

def Greeting():
    
    print("+" * 50)
    print("        Step into Hirdesh's Land Rental Property! ")
    print("              Made by Hirdesh Chauhan")
    print("+" * 50)

def LandDetails(directory):
    print("+" * 100)
    print("Kitta", "\t\t", "City", "\t\t", "Direction", "\t", "Anna","\t" ,"Price","\t\t","Status")
    print("+" * 100)
    for key,value in directory.items():
        print ((key)+"\t\t"+value[0]+"\t\t"+value[1]+"\t\t"+value[2]+"\t"+value[3]+"\t\t"+value[4])
        print()
def CHOICE():
    """ When the program runs, an introduction screen will show up. """
    print("\n")
    print("-" * 100)
    print("\n")
    print("Choose your choice of land")
    print("Enter 1 to rent land. ")
    print("Enter 2 to return land")
    print("Enter 3 to exit the system.")
    print("\n")
    print("-" * 100)

    choice = input("Enter the suitable choice:") 
    print()
    return choice
mon = {} 
price = {} 
def RentLand():
    SellBill = []
    global mon,price
    prefer = False
    while prefer == False:
        Customer_Name = input("Enter your name: ")
        Customer_Phone_num = input("Enter your phone no: ")
        Customer_Address = input("Enter your address: ")
        if Customer_Name.replace(" ","").isalpha() and Customer_Phone_num.isdigit() and Customer_Address.isalpha():
            prefer = True
            directory = read.readFile()
            LandDetails(directory)
            kittas = directory.keys() 
            say = False
            while say == False:
                assumekitta = False
                while assumekitta == False:
                    try:
                        Kitta = int (input("Enter the kitta number: "))
                        if str(Kitta) in  kittas:
                            Kitta = str (Kitta)
                            
                            if directory[Kitta][-1] == "Available":
                                assumeanna = False
                                while assumeanna == False:
                                    
                                    Anna = int (input("Enter anna : "))
                                    
                                    if str(Anna)== directory[Kitta][2]:
                                        print("Rented successfully.")
                                        assumeanna = True
                                        assumemonths = False
                                        while assumemonths == False:
                                            try:
                                                Months = int (input("Enter the time period of the land: "))
                                                if Months >0:
                                                    assumemonths = True
                                                else:
                                                    print("Enter time period of land.")
                                            except:
                                                print("Enter renting period of land.")
                                        directory[Kitta][-1] = "Not Available"
                                        tprice = Months * int (directory[Kitta][3])
                                        price[Kitta] = tprice
                                        mon[Kitta] = Months
                                        
                                        SellBill.append([Kitta,directory[Kitta][0],directory[Kitta][1],directory[Kitta][2],directory[Kitta][3],str(Months), str(tprice)])
                                        
                                    else:
                                        print("Invalid Anna")
                            
                            else:
                                print("Kitta is not available.")
                            assumekitta = True
                            
                        else:
                            print("Invalid Kitta.")
                            print()
                    except:
                        print("Invalid Input!")
                test = False
                while test == False:
                    Take = input("Do you want to rent more(yes/no)?")
                    if Take.lower() == "yes":
                        say = False
                        test = True
                        LandDetails(directory)
                    elif Take.lower() == "no":
                        test = True
                        say = True
                        print("Your bill is generated.")
                        print("\n")
                        write.remainingLand(directory)
                        write.rent_invoice(SellBill,Customer_Name,Customer_Address,Customer_Phone_num)
                    else:
                        
                        print("Invalid Input")
                
        else:
            print("Please input valid details")
        
def ReturnLand():
    SellBill = []
    global mon,price
    prefer = False
    while prefer == False:
        
        Customer_Name = input("Enter your name: ")
        Customer_Phone_num = input("Enter your number: ")
        Customer_Address = input("Enter your current address: ")
        if Customer_Name.replace(" ","").isalpha() and Customer_Phone_num.isdigit():
            prefer = True
            directory = read.readFile()
            
            LandDetails(directory)
            kittas = directory.keys()

            say = False
            while say == False:
                assumekitta = False
                while assumekitta == False:
                    try:
                        
                    
                        Kitta = int (input("Enter the kitta number: "))
                        Kitta = str (Kitta)
                        if Kitta in  kittas:
                            
                            if directory[Kitta][-1] == "Not Available":
                                
                                tally = False
                                while tally == False:
                                    try:
                                        months = int(input ("Previous rented time period: "))
                                        if months <= 0:
                                            print("Enter time period ")
                                        else:
                                            tally = True
                                    except:
                                        print("Enter number only")
                                try:
                                    if (int(months)) >  (int(mon[Kitta])): 
                                        fine = 0.5 * int (directory[Kitta][3]) * (int(months)-mon[Kitta]) # 1 is the full price of the land for exceeding months and 0.2 is the fine of the land 
                        
                                    else:
                                        fine = 0
                                    directory[Kitta][-1] = "Available"
                                    SellBill.append([Kitta,directory[Kitta][0],directory[Kitta][1],directory[Kitta][2],directory[Kitta][3],str(mon[Kitta]),str(months),str(fine),str(price[Kitta])])
                                except:
                                    print("Can't return ")
                            else:
                                print("without renting can't return.")
                            assumekitta = True        
                        else:
                            print("There is no such land.")
                    except:
                        print("valid input needed")
                test = False
                while test == False:
                    Take = input("Do you want to return more(yes/no)?")
                    if Take.lower() == "yes":
                        test = True
                        say = False
                        LandDetails(directory)
                    elif Take.lower() == "no":
                        test = True
                        say = True
                        print("Your bill is generated.")
                        print("\n")
                        write.remainingLand(directory)
                        write.return_invoice(SellBill,Customer_Name,Customer_Address,Customer_Phone_num)
                    else:
                        print("Invalid Input!")
        else:
            print("correct information ")
                            

def Thanks():
    print ("Thanks")
    
    
