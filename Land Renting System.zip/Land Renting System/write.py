import datetime

def remainingLand(directory):
    file = open("Lands.txt","w")
    for key,value in directory.items():
        file.write(key+",")
        for each in range(len(value)-1):
             file.write(value[each]+",")
        file.write(value[4])
        file.write("\n")
    file.close()


def rent_invoice(data,Name,Address,phoneNumber):

    Year = (datetime.datetime.now().year)
    Month = (datetime.datetime.now().month)
    Day = (datetime.datetime.now().day)
    Hour = (datetime.datetime.now().hour)
    Minute = (datetime.datetime.now().minute)
    Second = (datetime.datetime.now().second)
    microSecond = (datetime.datetime.now().microsecond)
    
    print("-" * 40)
    print("Bill of Land")
    print("-" * 40)
    print("Date:- " + str(Day) + "-" + str(Month) + "-" + str(Year))
    print("Customer's Name: " + Name)
    print("Customer's Phone Number: " + phoneNumber)
    print("Customer's Address: " + Address)
    print("-" * 40)
    Final_Price = 0
    
    
    
    
    
    text = "Rent_" + Name + str(Hour)+ str(Minute)+str(Second)+str(microSecond)+ ".txt"
    with open(text, "w") as file:
        
        file.write("-" * 40 + "\n")
        file.write("Bill of Land "+"\n")
        file.write("Date:- " + str(Day) + "-" + str(Month) + "-" + str(Year) + "\n")
        file.write("Customer's Name: " + Name + "\n")
        file.write("Customer's Phone Number: " + phoneNumber + "\n")
        file.write("Customer's Address: " + Address + "\n")
        
        file.write("-" * 40 + "\n")
        
        for each in data:
            print("Kitta:"+"\t\t\t"+ each[0])
            print("City:"+"\t\t\t"+ each[1])
            print("Direction:"+"\t\t"+ each[2])
            print("Anna:"+"\t\t\t"+ each[3])
            print("Price:"+"\t\t\t"+ each[4])
            print("Required Time Period:"+"\t"+ each[5])
            print("Total Price:"+"\t\t"+ each[6])

            file.write("Kitta:"+"\t\t\t"+ each[0]+"\n")
            file.write("City:"+"\t\t\t"+ each[1]+"\n")
            file.write("Direction:"+"\t\t"+ each[2]+"\n")
            file.write("Anna:"+"\t\t\t"+ each[3]+"\n")
            file.write("Price:"+"\t\t\t"+ each[4]+"\n")
            file.write("Required Time Period:"+"\t"+ each[5]+"\n")
            file.write("Total Price:"+"\t\t"+ each[6]+"\n")
            Final_Price = Final_Price + int(each[6])
        print("-" * 40)
        print("The total price of the land is "+ str (Final_Price)+" .")
        print("\n")
        print("-" * 40)

        file.write("-" * 40+"\n")
        file.write("The total price of the land is "+ str (Final_Price)+" .")
        
        
            
def return_invoice(data,Name,Address,phoneNumber):

    Year = (datetime.datetime.now().year)
    Month = (datetime.datetime.now().month)
    Day = (datetime.datetime.now().day)
    Hour = (datetime.datetime.now().hour)
    Minute = (datetime.datetime.now().minute)
    Second = (datetime.datetime.now().second)
    microSecond = (datetime.datetime.now().microsecond)
    
    print("-" * 50)
    print("Bill of Land   ")
    print("-" * 50)
    print("Date:- " + str(Day) + "-" + str(Month) + "-" + str(Year))
    print("Customer's Name: " + Name)
    print("Customer's Phone Number: " + phoneNumber)
    print("Customer's Address: " + Address)
    print("-" * 50)

    Final_Price = 0 # initializing the value
    Total_Fine = 0
    
    
    text = "Return_" + Name + str(Hour)+ str(Minute)+str(Second)+str(microSecond)+ ".txt"
    with open(text, "w") as file:
        
        file.write("-" * 50 + "\n")
        file.write("Bill of Land \n")
        file.write("Date:- " + str(Day) + "-" + str(Month) + "-" + str(Year) + "\n")
        file.write("Customer's Name: " + Name + "\n")
        file.write("Customer's Phone Number: " + phoneNumber + "\n")
        file.write("Customer's Address: " + Address + "\n")
        
        file.write("-" * 50 + "\n")
        
        
        for each in data:
            print("Kitta:"+"\t\t\t"+ each[0])
            print("City:"+"\t\t\t"+ each[1])
            print("Direction:"+"\t\t"+ each[2])
            print("Anna:"+"\t\t\t"+ each[3])
            print("Price:"+"\t\t\t"+ each[4])
            print("Reqiured Time:"+"\t\t"+ each[5])
            print("Current Time:"+"\t\t"+ each[6])
            print("Previous Price:"+"\t\t"+ each[8])
            print("Fine:"+"\t\t\t"+ each[7])

            file.write("Kitta:"+"\t\t\t"+ each[0]+"\n")
            file.write("City:"+"\t\t\t"+ each[1]+"\n")
            file.write("Direction:"+"\t\t"+ each[2]+"\n")
            file.write("Anna:"+"\t\t\t"+ each[3]+"\n")
            file.write("Price:"+"\t\t\t"+ each[4]+"\n")
            file.write("Required Time:"+"\t\t"+ each[5]+"\n")
            file.write("Current Time:"+"\t\t"+ each[6]+"\n")
            file.write("Previous Price:"+"\t\t"+ each[8]+"\n")
            file.write("Fine:"+"\t\t\t"+ each[7]+"\n")
            Final_Price = Final_Price + int(each[8])
            Total_Fine = Total_Fine + int(float(each[7]))
        Grand_Total = Total_Fine + Final_Price
            
        print("-" * 50)
        print("The price of the land with fine is "+ str (Total_Fine)+"\n")
        print("-" * 50)
        print("The price after fine added is "+ str (Final_Price)+"\n")
        print("-" * 50)
        print("The grand total of the land is "+ str (Grand_Total)+"\n")
        print("-" * 50)

        file.write("-" * 50+"\n")
        file.write("The price of the land with fine is "+ str(Total_Fine)+"\n")
        file.write("-" * 50+"\n")
        file.write("The price after fine added is "+ str (Final_Price)+"\n")
        file.write("-" * 50+"\n")
        file.write("The grand total of the land is "+ str (Grand_Total)+"\n")
        file.write("-" * 50+"\n")
        
            


