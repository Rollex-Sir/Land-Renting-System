def readFile():
    file = open("Lands.txt","r")
    data = file.readlines() 
    
    directory = {}
    for each in data:
        each = each.replace("\n", "") 
        var = each.split(",") 
        key = var[0]
        values = var[1:]
        directory[key]=values 
    return directory

