import datetime
import operation
import read
import write

operation.Greeting()
condition = True
while condition == True:
    
    choice = operation.CHOICE()
    if choice == "1":
        operation.RentLand()
    elif choice == "2":
        operation.ReturnLand()
    elif choice == "3":
        operation.Thanks()
        condition = False
    else:
        print("wrong input")
    
        
        
    
    
    
